package com.cts.project.ExpenseTracker.dao;

import org.springframework.stereotype.Component;

@Component
public class userid {
private String Userid;

public String getUserid() {
	return Userid;
}

public void setUserid(String userid) {
	Userid = userid;
}
}
