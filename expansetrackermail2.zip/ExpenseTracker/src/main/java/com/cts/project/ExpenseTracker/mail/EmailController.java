package com.cts.project.ExpenseTracker.mail;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.stereotype.Service;

import com.cts.project.ExpenseTracker.dao.User;

@Service
public class EmailController {
       public void sendmail() throws AddressException, MessagingException, IOException {
	   Properties props = new Properties();
	   props.put("mail.smtp.auth", "true");
	   props.put("mail.smtp.starttls.enable", "true");
	   props.put("mail.smtp.host", "smtp.gmail.com");
	   props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
	   props.put("mail.smtp.port", "587");
	   
	   Session session = Session.getInstance(props, new Authenticator() {
	      protected PasswordAuthentication getPasswordAuthentication() {
	         return new PasswordAuthentication("ashvanijaiswal7897@gmail.com", "9307638130@");
	         //enter your email and password here
	      }
	   });
	   Message msg = new MimeMessage(session);
	   msg.setFrom(new InternetAddress("ashvanijaiswal7897@gmail.com", false));
	   //enter your email

	   msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("ashvanijaiswal7897@gmail.com"));
//	 wagh.kaustubh2@gmail.com receiver email id  u can change to you want to send...
	   msg.setSubject("Expanse Tracker Project");
	   msg.setContent("Expense Tracker says Hi to his user how can I help you?", "text/html");
	   msg.setSentDate(new Date());

	   MimeBodyPart messageBodyPart = new MimeBodyPart();
	   messageBodyPart.setContent("Tutorials point email", "text/html");
	   Transport.send(msg);   
	}
      public static void main(String[] args) throws AddressException, MessagingException, IOException {
    	  EmailController e=new EmailController();
    	  System.out.println("before sending....");
    	  e.sendmail();
    	  System.out.println("your mail have been succesfully send");
	}
      
}
	